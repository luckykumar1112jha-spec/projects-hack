document.addEventListener('DOMContentLoaded', function() {
            const loadingScreen = document.getElementById('loadingScreen');
            const loadingBar = document.getElementById('loadingBar');
            const loadingText = document.getElementById('loadingText');
            
            let progress = 0;
            const interval = setInterval(() => {
                progress += Math.random() * 15;
                if (progress > 100) progress = 100;
                loadingBar.style.width = `${progress}%`;
                
                if (progress < 30) {
                    loadingText.textContent = "Initializing Dashboard...";
                } else if (progress < 60) {
                    loadingText.textContent = "Loading Data Sources...";
                } else if (progress < 90) {
                    loadingText.textContent = "Processing Analytics...";
                } else {
                    loadingText.textContent = "Finalizing Setup...";
                }
                
                if (progress === 100) {
                    clearInterval(interval);
                    setTimeout(() => {
                        loadingScreen.classList.add('hidden');
                    }, 500);
                }
            }, 200);
            
            // Initialize particles.js
            particlesJS('particles-js', {
                particles: {
                    number: {
                        value: 100,
                        density: {
                            enable: true,
                            value_area: 800
                        }
                    },
                    color: {
                        value: "#00A8E8"
                    },
                    shape: {
                        type: "circle",
                        stroke: {
                            width: 0,
                            color: "#000000"
                        }
                    },
                    opacity: {
                        value: 0.5,
                        random: true,
                        anim: {
                            enable: true,
                            speed: 1,
                            opacity_min: 0.1,
                            sync: false
                        }
                    },
                    size: {
                        value: 3,
                        random: true,
                        anim: {
                            enable: true,
                            speed: 2,
                            size_min: 0.1,
                            sync: false
                        }
                    },
                    line_linked: {
                        enable: true,
                        distance: 150,
                        color: "#00A8E8",
                        opacity: 0.2,
                        width: 1
                    },
                    move: {
                        enable: true,
                        speed: 1,
                        direction: "none",
                        random: true,
                        straight: false,
                        out_mode: "out",
                        bounce: false,
                        attract: {
                            enable: false,
                            rotateX: 600,
                            rotateY: 1200
                        }
                    }
                },
                interactivity: {
                    detect_on: "canvas",
                    events: {
                        onhover: {
                            enable: true,
                            mode: "grab"
                        },
                        onclick: {
                            enable: true,
                            mode: "push"
                        },
                        resize: true
                    },
                    modes: {
                        grab: {
                            distance: 140,
                            line_linked: {
                                opacity: 0.5
                            }
                        },
                        push: {
                            particles_nb: 4
                        }
                    }
                },
                retina_detect: true
            });

            // Usage Chart
            const usageCtx = document.getElementById('usageChart').getContext('2d');
            const usageChart = new Chart(usageCtx, {
                type: 'line',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Water Usage (ML)',
                        data: [120, 150, 180, 170, 160, 200, 190],
                        borderColor: '#00A8E8',
                        backgroundColor: 'rgba(0, 168, 232, 0.1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: '#00A8E8',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 7
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(13, 25, 47, 0.9)',
                            titleColor: '#E6F1FF',
                            bodyColor: '#E6F1FF',
                            borderColor: '#00A8E8',
                            borderWidth: 1,
                            cornerRadius: 8,
                            displayColors: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        }
                    }
                }
            });

            // Pollution Chart
            const pollutionCtx = document.getElementById('pollutionChart').getContext('2d');
            const pollutionChart = new Chart(pollutionCtx, {
                type: 'bar',
                data: {
                    labels: ['Industrial', 'Agricultural', 'Residential', 'Natural'],
                    datasets: [{
                        label: 'Pollution Level (PPM)',
                        data: [65, 40, 25, 15],
                        backgroundColor: [
                            'rgba(231, 76, 60, 0.7)',
                            'rgba(241, 196, 15, 0.7)',
                            'rgba(0, 168, 232, 0.7)',
                            'rgba(46, 204, 113, 0.7)'
                        ],
                        borderColor: [
                            'rgb(231, 76, 60)',
                            'rgb(241, 196, 15)',
                            'rgb(0, 168, 232)',
                            'rgb(46, 204, 113)'
                        ],
                        borderWidth: 2,
                        borderRadius: 8,
                        borderSkipped: false,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(13, 25, 47, 0.9)',
                            titleColor: '#E6F1FF',
                            bodyColor: '#E6F1FF',
                            borderColor: '#00A8E8',
                            borderWidth: 1,
                            cornerRadius: 8
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        }
                    }
                }
            });

            // Chart button interactions
            document.querySelectorAll('.chart-btn').forEach(button => {
                button.addEventListener('click', function() {
                    // Remove active class from all buttons in the same container
                    this.parentElement.querySelectorAll('.chart-btn').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    
                    // Add active class to clicked button
                    this.classList.add('active');
                });
            });

            // Map region interactions
            document.querySelectorAll('.map-region').forEach(region => {
                region.addEventListener('click', function() {
                    const regionName = this.getAttribute('data-region');
                    
                    // Add visual feedback
                    this.style.transform = 'scale(1.1)';
                    this.style.boxShadow = '0 0 25px rgba(46, 204, 113, 0.5)';
                    
                    setTimeout(() => {
                        this.style.transform = 'scale(1.05)';
                        this.style.boxShadow = '0 5px 15px rgba(46, 204, 113, 0.3)';
                    }, 300);
                    
                    console.log(`Selected region: ${regionName}`);
                });
            });

            // Simulate real-time data updates
            function updateStats() {
                const statCards = document.querySelectorAll('.stat-card');
                statCards.forEach(card => {
                    const valueElement = card.querySelector('.stat-value');
                    const progressBar = card.querySelector('.progress-bar');
                    const currentValue = parseFloat(valueElement.textContent);
                    
                    // Simulate small fluctuations in data
                    const fluctuation = (Math.random() - 0.5) * 2;
                    const newValue = Math.max(0, currentValue + fluctuation);
                    
                    // Update the value with animation
                    valueElement.style.transform = 'scale(1.1)';
                    setTimeout(() => {
                        valueElement.textContent = newValue.toFixed(1) + (valueElement.textContent.includes('%') ? '%' : '');
                        valueElement.style.transform = 'scale(1)';
                    }, 150);
                    
                    // Update progress bar
                    if (progressBar) {
                        const newWidth = Math.min(100, Math.max(0, newValue));
                        progressBar.style.width = `${newWidth}%`;
                    }
                });
            }

            // Update stats every 10 seconds
            setInterval(updateStats, 10000);

            // Add scroll animations
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);

            // Observe elements for animation
            document.querySelectorAll('.stat-card, .chart-container, .alerts-panel, .map-container').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });

            // Scroll to top functionality
            const scrollToTopBtn = document.getElementById('scrollToTop');
            
            window.addEventListener('scroll', () => {
                if (window.pageYOffset > 300) {
                    scrollToTopBtn.classList.add('visible');
                } else {
                    scrollToTopBtn.classList.remove('visible');
                }
                
                // Header scroll effect
                const header = document.getElementById('mainHeader');
                if (window.pageYOffset > 50) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            });
            
            scrollToTopBtn.addEventListener('click', () => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

            // Mobile menu toggle
            const menuToggle = document.getElementById('menuToggle');
            const mainNav = document.getElementById('mainNav');
            
            menuToggle.addEventListener('click', () => {
                mainNav.classList.toggle('active');
                menuToggle.classList.toggle('active');
            });

            // Notification toast
            const notificationToast = document.getElementById('notificationToast');
            const notificationClose = document.getElementById('notificationClose');
            
            // Show notification after 3 seconds
            setTimeout(() => {
                notificationToast.classList.add('visible');
            }, 3000);
            
            notificationClose.addEventListener('click', () => {
                notificationToast.classList.remove('visible');
            });

            // Auto-hide notification after 5 seconds
            setTimeout(() => {
                notificationToast.classList.remove('visible');
            }, 8000);

            // Create animated data points
            function createDataPoints() {
                const container = document.querySelector('.data-points-container');
                for (let i = 0; i < 20; i++) {
                    const point = document.createElement('div');
                    point.classList.add('data-point');
                    point.style.left = `${Math.random() * 100}%`;
                    point.style.top = `${Math.random() * 100}%`;
                    point.style.animationDelay = `${Math.random() * 3}s`;
                    point.style.backgroundColor = i % 4 === 0 ? 'var(--primary)' : 
                                                 i % 4 === 1 ? 'var(--green)' : 
                                                 i % 4 === 2 ? 'var(--yellow)' : 'var(--red)';
                    container.appendChild(point);
                }
            }
            
            createDataPoints();

            // Add click effects to stat cards
            document.querySelectorAll('.stat-card').forEach(card => {
                card.addEventListener('click', function() {
                    this.style.transform = 'scale(0.95)';
                    setTimeout(() => {
                        this.style.transform = 'translateY(-8px)';
                    }, 150);
                });
            });

            // Add ripple effect to buttons
            document.querySelectorAll('button, .stat-card, .map-region, .alert-item').forEach(element => {
                element.addEventListener('click', function(e) {
                    const ripple = document.createElement('span');
                    const rect = this.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    const x = e.clientX - rect.left - size / 2;
                    const y = e.clientY - rect.top - size / 2;
                    
                    ripple.style.width = ripple.style.height = `${size}px`;
                    ripple.style.left = `${x}px`;
                    ripple.style.top = `${y}px`;
                    ripple.classList.add('ripple-effect');
                    
                    this.appendChild(ripple);
                    
                    setTimeout(() => {
                        ripple.remove();
                    }, 600);
                });
            });

            // Add CSS for ripple effect
            const rippleStyle = document.createElement('style');
            rippleStyle.textContent = `
                .ripple-effect {
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.5);
                    transform: scale(0);
                    animation: ripple-animation 0.6s linear;
                    pointer-events: none;
                }
                
                @keyframes ripple-animation {
                    to {
                        transform: scale(4);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(rippleStyle);
        });

 // Initialize Charts
        document.addEventListener('DOMContentLoaded', function() {
            // Water Usage Chart
            const usageCtx = document.getElementById('usageChart').getContext('2d');
            const usageChart = new Chart(usageCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
                    datasets: [{
                        label: 'Water Usage (Million Gallons)',
                        data: [65, 59, 80, 81, 56, 55, 40],
                        borderColor: '#00A8E8',
                        backgroundColor: 'rgba(0, 168, 232, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        }
                    }
                }
            });

            // Pollution Chart
            const pollutionCtx = document.getElementById('pollutionChart').getContext('2d');
            const pollutionChart = new Chart(pollutionCtx, {
                type: 'bar',
                data: {
                    labels: ['Reservoirs', 'Rivers', 'Groundwater', 'Treatment Plants'],
                    datasets: [{
                        label: 'Pollution Level (PPM)',
                        data: [30, 45, 25, 15],
                        backgroundColor: [
                            'rgba(46, 204, 113, 0.7)',
                            'rgba(241, 196, 15, 0.7)',
                            'rgba(231, 76, 60, 0.7)',
                            'rgba(0, 168, 232, 0.7)'
                        ],
                        borderColor: [
                            '#2ECC71',
                            '#F1C40F',
                            '#E74C3C',
                            '#00A8E8'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                color: '#E6F1FF'
                            }
                        }
                    }
                }
            });

            // Interactive Map Regions
            const regions = document.querySelectorAll('.map-region');
            regions.forEach(region => {
                region.addEventListener('click', function() {
                    const regionName = this.getAttribute('data-region');
                    alert(`Showing data for ${this.textContent.trim()}`);
                    // In a real application, this would update the dashboard with region-specific data
                });
            });

            // Simulate Real-time Data Updates
            setInterval(updateStats, 5000);
        });

        // Function to simulate real-time data updates
        function updateStats() {
            // Randomly update water availability
            const availabilityElement = document.querySelector('.stat-card:nth-child(1) .stat-value');
            let currentAvailability = parseInt(availabilityElement.textContent);
            let newAvailability = currentAvailability + (Math.random() > 0.5 ? 1 : -1) * Math.floor(Math.random() * 2);
            newAvailability = Math.max(70, Math.min(95, newAvailability)); // Keep between 70-95%
            availabilityElement.textContent = newAvailability + '%';

            // Randomly update pollution level
            const pollutionElement = document.querySelector('.stat-card:nth-child(2) .stat-value');
            let currentPollution = parseInt(pollutionElement.textContent);
            let newPollution = currentPollution + (Math.random() > 0.5 ? 1 : -1) * Math.floor(Math.random() * 3);
            newPollution = Math.max(35, Math.min(55, newPollution)); // Keep between 35-55 PPM
            pollutionElement.textContent = newPollution + ' PPM';

            // Update last updated time
            const now = new Date();
            document.querySelectorAll('.stat-label').forEach(label => {
                if (label.textContent.includes('Last Updated')) {
                    label.textContent = 'Last Updated: ' + now.toLocaleTimeString();
                }
            });
        }
        document.getElementById("saveWater").addEventListener("click", function(event) {
    event.preventDefault(); // stops redirecting to earth.png
    alert("🚰 Please save water! Every drop counts.");
});

        
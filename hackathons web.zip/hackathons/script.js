// Static region data
const regionData = {
    "North Zone": {
        supply: 72,
        pollution: 34,
        plants: 5,
        demand: 120
    },
    "Central Basin": {
        supply: 61,
        pollution: 41,
        plants: 3,
        demand: 140
    },
    "Coastal Line": {
        supply: 55,
        pollution: 49,
        plants: 4,
        demand: 160
    }
};

// Load Region Data
function loadRegion(region) {
    document.getElementById("region-title").innerText = region;

    const data = regionData[region];

    document.getElementById("supply-value").innerText = data.supply + "%";
    document.getElementById("pollution-value").innerText = data.pollution + " PPM";
    document.getElementById("plants-value").innerText = data.plants;
    document.getElementById("demand-value").innerText = data.demand + " ML";

    updateChart(data.supply, data.pollution);
    generateAlert(data);
}

// Alerts logic
function generateAlert(data) {
    const alerts = document.getElementById("alert-list");
    alerts.innerHTML = ""; // Reset

    if (data.supply < 50) {
        alerts.innerHTML += `<li>⚠ Low water supply detected.</li>`;
    }
    if (data.pollution > 45) {
        alerts.innerHTML += `<li>🔥 Pollution spike detected.</li>`;
    }
    if (data.demand > 150) {
        alerts.innerHTML += `<li>💧 High water demand today.</li>`;
    }
}

// Chart.js graph
let chart = new Chart(document.getElementById("waterChart"), {
    type: "line",
    data: {
        labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        datasets: [{
            label: "Water Supply %",
            borderWidth: 2,
            fill: false,
            borderColor: "#00a8e8",
            data: [60, 65, 62, 70, 72, 68, 66]
        }]
    }
});

function updateChart(supply, pollution) {
    chart.data.datasets[0].data[6] = supply;
    chart.update();
}

/* ========================= BASIC UI & SIDEBAR ========================= */
const app = document.getElementById('app');
const toggleSidebarBtn = document.getElementById('toggleSidebar'); // may be undefined if not present; safe-check below
const hamburger = document.getElementById('hamburger');
const navItems = document.querySelectorAll('.nav .item');

let sidebarOpen = false;
function setSidebar(open){
  if(open) app.classList.add('sidebar-open'); else app.classList.remove('sidebar-open');
}
if (toggleSidebarBtn) toggleSidebarBtn.addEventListener('click', ()=> { sidebarOpen = !sidebarOpen; setSidebar(sidebarOpen); });
hamburger?.addEventListener('click', ()=> { sidebarOpen = !sidebarOpen; setSidebar(sidebarOpen); });

navItems.forEach(it => {
  it.addEventListener('click', () => {
    navItems.forEach(i => i.classList.remove('active'));
    it.classList.add('active');
  });
});

/* ========================= REGION MODAL ========================= */
const regionModal = document.getElementById('regionModal');
const regionTitle = document.getElementById('regionTitle');
const regionDesc = document.getElementById('regionDesc');
const closeRegionModal = document.getElementById('closeRegionModal');

document.getElementById('regionGrid').addEventListener('click', (e) => {
  const tile = e.target.closest('.tile');
  if(!tile) return;
  const region = tile.dataset.region || tile.textContent;
  const details = {
    'North States': 'Reservoir: 72%. Pollution: 22 PPM. Alerts: 1 active.',
    'South States': 'Reservoir: 61%. Pollution: 31 PPM. Alerts: 2 active.',
    'Central States': 'Reservoir: 81%. Pollution: 18 PPM. Alerts: none.',
    'East States': 'Reservoir: 68%. Pollution: 26 PPM. Alerts: none.',
    'West States': 'Reservoir: 54%. Pollution: 45 PPM. Alerts: 3 active.'
  };
  regionTitle.textContent = region;
  regionDesc.textContent = details[region] || 'No details available.';
  regionModal.classList.add('open');
  regionModal.setAttribute('aria-hidden','false');
});
closeRegionModal.addEventListener('click', ()=> {
  regionModal.classList.remove('open');
  regionModal.setAttribute('aria-hidden','true');
});
regionModal.addEventListener('click', (e)=> { if(e.target === regionModal) { regionModal.classList.remove('open'); regionModal.setAttribute('aria-hidden','true'); } });

/* ========================= FOOTER MODALS: open/close handlers ========================= */
function setupFooterModal(linkId, modalId, closeBtnId) {
  const link = document.getElementById(linkId);
  const modal = document.getElementById(modalId);
  const closeBtn = document.getElementById(closeBtnId);

  if(!link || !modal || !closeBtn) return;
  link.addEventListener('click', (ev)=> {
    ev.preventDefault();
    modal.classList.add('open');
    modal.setAttribute('aria-hidden','false');
  });
  closeBtn.addEventListener('click', ()=> {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden','true');
  });
  modal.addEventListener('click', (e)=> { if(e.target === modal) { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); } });
}

setupFooterModal('footerContact','modalContact','closeContact');
setupFooterModal('footerTerms','modalTerms','closeTerms');
setupFooterModal('footerResources','modalResources','closeResources');
setupFooterModal('footerSupport','modalSupport','closeSupport');

/* Contact form send (demo) */
document.getElementById('sendContact').addEventListener('click', ()=>{
  const name = document.getElementById('contactName').value.trim();
  const msg = document.getElementById('contactMessage').value.trim();
  if(!name || !msg){
    alert('Please provide name and message.');
    return;
  }
  alert('Message sent — thank you, ' + name + ' (demo)');
  // clear
  document.getElementById('contactName').value = '';
  document.getElementById('contactMessage').value = '';
  document.getElementById('modalContact').classList.remove('open');
  document.getElementById('modalContact').setAttribute('aria-hidden','true');
});

/* ========================= LOGIN (Gmail-only) ========================= */
const loginScreen = document.getElementById('loginScreen');
const loginBtn = document.getElementById('loginBtn');
const loginCancel = document.getElementById('loginCancel');
const openLoginBtn = document.getElementById('openLoginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const loginEmail = document.getElementById('loginEmail');

function showLogin(show){
  loginScreen.style.display = show ? 'flex' : 'none';
  loginScreen.setAttribute('aria-hidden', show ? 'false' : 'true');
}
openLoginBtn.addEventListener('click', ()=> showLogin(true));
loginCancel.addEventListener('click', ()=> showLogin(false));

loginBtn.addEventListener('click', ()=> {
  const email = loginEmail.value.trim();
  if(!email.endsWith('@gmail.com')){
    loginEmail.style.border = '1px solid #ff6b6b';
    loginEmail.style.animation = 'shake .3s';
    setTimeout(()=> loginEmail.style.animation='', 300);
    alert('Email must end with @gmail.com');
    return;
  }
  loginBtn.disabled = true;
  loginBtn.textContent = 'Signing in...';
  setTimeout(()=> {
    loginBtn.disabled = false;
    loginBtn.textContent = 'Login';
    showLogin(false);
    openLoginBtn.style.display = 'none';
    logoutBtn.style.display = 'inline-block';
    startRealtimeSimulation();
  }, 700);
});

logoutBtn.addEventListener('click', ()=> {
  openLoginBtn.style.display = 'inline-block';
  logoutBtn.style.display = 'none';
  showLogin(true);
});

/* ========================= CHARTS ========================= */
const usageCtx = document.getElementById('usageChart').getContext('2d');

// initial data (12 points)
let usageLabels = Array.from({length:12}, (_,i)=> new Date(Date.now()-(11-i)*2000).toLocaleTimeString());
let usageData = [62,58,78,82,60,56,40,48,52,50,54,58];

const usageChart = new Chart(usageCtx, {
  type:'line',
  data:{
    labels:usageLabels,
    datasets:[{
      data:usageData,
      borderColor: 'rgba(20,255,176,1)',
      backgroundColor: 'rgba(20,255,176,0.10)',
      tension:0.36,
      pointRadius:3,
      fill:true
    }]
  },
  options:{
    maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{
      x:{ ticks:{ color:'#bfeefc' }, grid:{ color:'rgba(255,255,255,0.03)'} },
      y:{ ticks:{ color:'#bfeefc' }, grid:{ color:'rgba(255,255,255,0.03)'}, suggestedMax:100 }
    }
  }
});

const pollCtx = document.getElementById('pollutionChart').getContext('2d');
new Chart(pollCtx, {
  type:'bar',
  data:{
    labels:['Reservoirs','Rivers','Groundwater','Plants'],
    datasets:[{
      data:[30,45,25,15],
      backgroundColor:['#2fbf7f','#ffd23f','#ff6b6b','#4fd0ff'],
      borderRadius:8
    }]
  },
  options:{ maintainAspectRatio:false, plugins:{legend:{display:false}} }
});

/* ========================= REAL-TIME SIMULATION ========================= */
let simInterval = null;
let simRunning = false;

function startRealtimeSimulation(){
  if(simRunning) return;
  simRunning = true;
  simInterval = setInterval(()=>{
    const last = usageData[usageData.length-1] || 50;
    const drift = (Math.random()-0.45) * 8;
    let next = Math.max(10, Math.min(95, Math.round(last + drift)));
    usageData.push(next);
    usageLabels.push(new Date().toLocaleTimeString());
    if(usageData.length>12){ usageData.shift(); usageLabels.shift(); }
    usageChart.data.labels = usageLabels;
    usageChart.data.datasets[0].data = usageData;
    usageChart.update('active');
    document.getElementById('availValue').textContent = Math.max(10, 100 - Math.round((next/100)*40)) + '%';
  }, 2000);
}

/* accessibility: close modals with ESC */
document.addEventListener('keydown', (e)=> {
  if(e.key === 'Escape'){
    document.querySelectorAll('.modal-backdrop.open').forEach(m => {
      m.classList.remove('open');
      m.setAttribute('aria-hidden','true');
    });
  }
});
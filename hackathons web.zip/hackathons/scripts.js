// --- 1. SIMULATED DATA & CONFIGURATION ---

const REGIONS = [
    { id: 'R1', name: 'Zone 1 (River Delta)', population: '4.5M', source: 'River', capacity: '95%', dailyPressure: 75, pollutionBase: 120, availabilityBase: 90, usage: [50, 55, 60, 58, 62, 65, 68] },
    { id: 'R2', name: 'Zone 2 (Coastal)', population: '2.1M', source: 'Desalination', capacity: '80%', dailyPressure: 60, pollutionBase: 80, availabilityBase: 75, usage: [40, 42, 45, 43, 48, 50, 52] },
    { id: 'R3', name: 'Zone 3 (Upland Reservoir)', population: '3.8M', source: 'Reservoir', capacity: '100%', dailyPressure: 88, pollutionBase: 60, availabilityBase: 95, usage: [70, 72, 75, 71, 78, 80, 85] },
    { id: 'R4', name: 'Zone 4 (Industrial Park)', population: '1.2M', source: 'Groundwater', capacity: '70%', dailyPressure: 55, pollutionBase: 150, availabilityBase: 65, usage: [30, 32, 35, 33, 38, 40, 42] }
];

const INITIAL_METRICS = {
    // Global metrics (simulated)
    availability: 85,
    pollution: 95, // PPM
    purification: 8, // Plants Active
    qualityGrade: 'B+',
};

let currentMetrics = {...INITIAL_METRICS};
let currentRegion = 'R1';
let alerts = [];
const MAX_ALERTS = 5;

// --- 2. CHART INITIALIZATION (Chart.js) ---
let usageLineChart, pollutionBarChart, profilePollutionBar;

function initializeCharts() {
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                labels: { color: '#E0E7FF' }
            }
        },
        scales: {
            x: { grid: { color: '#1A2940' }, ticks: { color: '#E0E7FF' } },
            y: { grid: { color: '#1A2940' }, ticks: { color: '#E0E7FF' } }
        }
    };

    // a. Daily Water Usage Trend (Line Chart)
    const usageCtx = document.getElementById('usageLineChart').getContext('2d');
    usageLineChart = new Chart(usageCtx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Usage (Million Liters)',
                data: REGIONS.map(r => r.usage).flat().sort(() => 0.5 - Math.random()).slice(0, 7), // Mix of data
                borderColor: '#00A8E8',
                backgroundColor: 'rgba(0, 168, 232, 0.2)',
                tension: 0.4
            }]
        },
        options: {...defaultOptions, scales: {...defaultOptions.scales, y: {...defaultOptions.scales.y, beginAtZero: true}}}
    });

    // b. Regional Pollution Comparison (Bar Chart)
    const pollutionCtx = document.getElementById('pollutionBarChart').getContext('2d');
    pollutionBarChart = new Chart(pollutionCtx, {
        type: 'bar',
        data: {
            labels: REGIONS.map(r => r.name),
            datasets: [{
                label: 'Pollution Level (PPM)',
                data: REGIONS.map(r => r.pollutionBase + Math.floor(Math.random() * 20)),
                backgroundColor: ['#E74C3C', '#F1C40F', '#2ECC71', '#F1C40F']
            }]
        },
        options: {...defaultOptions, scales: {...defaultOptions.scales, y: {...defaultOptions.scales.y, beginAtZero: true}}}
    });

    // c. Region Profile Pollution Bar
    const profileCtx = document.getElementById('profilePollutionBar').getContext('2d');
    profilePollutionBar = new Chart(profileCtx, {
        type: 'bar',
        data: {
            labels: ['Pollution Level'],
            datasets: [{
                label: 'PPM',
                data: [0], // Initial data will be set on region click
                backgroundColor: '#00A8E8'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: '#E0E7FF' },
                    max: 200, // Fixed scale for comparison
                    beginAtZero: true
                },
                y: { display: false }
            }
        }
    });
}

// --- 3. DOM & DASHBOARD RENDER FUNCTIONS ---

/**
 * Updates the main dashboard statistics cards.
 */
function updateDashboardCards() {
    const cardsContainer = document.getElementById('stat-cards');
    cardsContainer.innerHTML = ''; // Clear previous cards

    const cardData = [
        { label: 'Water Availability %', value: currentMetrics.availability.toFixed(1) + '%', icon: 'fa-tint', threshold: { green: 80, yellow: 60, red: 0 } },
        { label: 'Pollution Level (PPM)', value: currentMetrics.pollution.toFixed(1), icon: 'fa-flask', threshold: { green: 0, yellow: 100, red: 150 }, reverse: true },
        { label: 'Purification Plants Active', value: currentMetrics.purification, icon: 'fa-industry', threshold: { green: 8, yellow: 5, red: 0 } },
        { label: 'Water Quality Grade', value: currentMetrics.qualityGrade, icon: 'fa-certificate' }
    ];

    cardData.forEach(data => {
        let statusClass = '';
        if (data.threshold) {
            if (data.reverse) { // For pollution: lower is better (green)
                if (data.value <= data.threshold.yellow) statusClass = 'status-green';
                else if (data.value <= data.threshold.red) statusClass = 'status-yellow';
                else statusClass = 'status-red';
            } else { // For availability/plants: higher is better (green)
                if (parseFloat(data.value) >= data.threshold.green) statusClass = 'status-green';
                else if (parseFloat(data.value) >= data.threshold.yellow) statusClass = 'status-yellow';
                else statusClass = 'status-red';
            }
        } else if (data.label === 'Water Quality Grade') {
            if (data.value.startsWith('A')) statusClass = 'status-green';
            else if (data.value.startsWith('B')) statusClass = 'status-yellow';
            else statusClass = 'status-red';
        }
        
        const html = `
            <div class="stat-card card">
                <i class="fas ${data.icon}"></i>
                <div class="value ${statusClass}">${data.value}</div>
                <div class="label">${data.label}</div>
            </div>
        `;
        cardsContainer.innerHTML += html;
    });

    document.getElementById('last-updated-time').textContent = `Last Updated: ${new Date().toLocaleTimeString()}`;
}

/**
 * Handles the logic for displaying regional data on click.
 * @param {string} regionId - The ID of the clicked region (e.g., 'R1').
 */
function selectRegion(regionId) {
    currentRegion = regionId;
    const region = REGIONS.find(r => r.id === regionId);

    // 1. Update Profile Card
    document.getElementById('profile-name').textContent = region.name;
    document.getElementById('profile-population').textContent = region.population;
    document.getElementById('profile-source').textContent = region.source;
    document.getElementById('profile-capacity').textContent = region.capacity;

    // 2. Update Profile Pollution Chart
    const pollutionData = region.pollutionBase + Math.floor(Math.random() * 20); // Current region pollution
    
    // Update chart data and color based on pollution level
    let barColor = '#2ECC71';
    if (pollutionData > 100) barColor = '#F1C40F';
    if (pollutionData > 150) barColor = '#E74C3C';

    profilePollutionBar.data.datasets[0].data = [pollutionData];
    profilePollutionBar.data.datasets[0].backgroundColor = barColor;
    profilePollutionBar.update();

    // 3. Update Map Highlight
    document.querySelectorAll('.region-placeholder').forEach(el => {
        el.classList.remove('R-highlighted');
        if (el.dataset.region === regionId) {
            el.classList.add('R-highlighted');
        }
    });
}

/**
 * Updates the map color-coding based on the current availability.
 */
function updateMapColors() {
    REGIONS.forEach(region => {
        const el = document.getElementById(region.id);
        if (!el) return;

        // Simple region availability calculation
        const availability = region.availabilityBase + (currentMetrics.availability - INITIAL_METRICS.availability);
        
        el.classList.remove('R-status-green', 'R-status-yellow', 'R-status-red');

        if (availability > 85) {
            el.classList.add('R-status-green');
        } else if (availability > 70) {
            el.classList.add('R-status-yellow');
        } else {
            el.classList.add('R-status-red');
        }
    });
    // Ensure the current highlighted region remains selected after color update
    selectRegion(currentRegion);
}

/**
 * Updates the Alert sidebar and count.
 */
function updateAlertsSidebar() {
    const alertsList = document.getElementById('alerts-list');
    
    // Clear the list and re-render the latest MAX_ALERTS
    alertsList.innerHTML = ''; 

    if (alerts.length === 0) {
        alertsList.innerHTML = '<p class="no-alerts">System Status: All clear.</p>';
    } else {
        // Show only the latest 5 alerts
        alerts.slice(-MAX_ALERTS).reverse().forEach(alert => {
            const alertDiv = document.createElement('div');
            alertDiv.classList.add('alert-item', alert.type);
            alertDiv.innerHTML = `<strong>${alert.timestamp}</strong>: ${alert.message}`;
            alertsList.appendChild(alertDiv);
        });
    }

    // Update the counter in the navigation bar
    document.getElementById('alert-count').textContent = alerts.length > 0 ? alerts.length : 0;
}

// --- 4. LIVE SIMULATION LOGIC ---

/**
 * Simulates data fluctuation and triggers alerts.
 */
function simulateUpdate() {
    // 1. Fluctuate Global Metrics
    const rand = (max, min) => Math.random() * (max - min) + min;
    const adjust = () => rand(1, -1);

    currentMetrics.availability = Math.min(100, Math.max(50, currentMetrics.availability + adjust() * 0.5));
    currentMetrics.pollution = Math.min(200, Math.max(50, currentMetrics.pollution + adjust() * 2));
    currentMetrics.purification = Math.min(10, Math.max(5, currentMetrics.purification + Math.round(adjust() * 0.1)));

    // Update Quality Grade based on Pollution
    if (currentMetrics.pollution < 80) currentMetrics.qualityGrade = 'A-';
    else if (currentMetrics.pollution < 120) currentMetrics.qualityGrade = 'B+';
    else if (currentMetrics.pollution < 150) currentMetrics.qualityGrade = 'C';
    else currentMetrics.qualityGrade = 'D-';

    // 2. Trigger Alerts based on thresholds
    const timestamp = new Date().toLocaleTimeString();
    
    // Low Availability Alert (Zone 2 - R2)
    if (REGIONS[1].availabilityBase + (currentMetrics.availability - INITIAL_METRICS.availability) < 70 && Math.random() < 0.3) {
        alerts.push({
            timestamp: timestamp,
            message: `⚠ Low Water Supply in Zone 2. Current Availability: ${currentMetrics.availability.toFixed(1)}%`,
            type: 'alert-low'
        });
    }

    // High Pollution Alert
    if (currentMetrics.pollution > 150 && Math.random() < 0.2) {
        alerts.push({
            timestamp: timestamp,
            message: `🔥 Pollution Spike Detected! Global PPM at ${currentMetrics.pollution.toFixed(1)}.`,
            type: 'alert-spike'
        });
    }

    // Purification Plant Offline Alert
    if (currentMetrics.purification < 6 && Math.random() < 0.1) {
         alerts.push({
            timestamp: timestamp,
            message: `💧 Purification Plant Offline in Sector 2. Active Plants: ${currentMetrics.purification}`,
            type: 'alert-offline'
        });
    }

    // 3. Update all DOM elements
    updateDashboardCards();
    updateMapColors();
    updateAlertsSidebar();

    // 4. Update Charts with new data (simulated change)
    // Update the pollution bar chart with new fluctuating data
    pollutionBarChart.data.datasets[0].data = REGIONS.map(r => r.pollutionBase + Math.floor(rand(10, -10)) + (currentMetrics.pollution - INITIAL_METRICS.pollution));
    pollutionBarChart.update();

    // Update the region profile if it's currently selected
    if (document.getElementById('profile-name').textContent !== 'Select a Region') {
        selectRegion(currentRegion);
    }
}

// --- 5. INITIALIZATION & EVENT LISTENERS ---

function initAquaSync() {
    // 1. Initialize Charts
    initializeCharts();

    // 2. Initial Data Load
    updateDashboardCards();
    updateMapColors();
    updateAlertsSidebar();
    selectRegion('R1'); // Set a default selected region

    // 3. Set up the Live Simulation Timer
    // Runs every 5 seconds (5000ms)
    setInterval(simulateUpdate, 5000); 

    // 4. Attach Map Interactivity
    document.querySelectorAll('.region-placeholder').forEach(el => {
        el.addEventListener('click', (e) => {
            selectRegion(e.target.dataset.region);
        });
    });
}

// Start the application when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initAquaSync);